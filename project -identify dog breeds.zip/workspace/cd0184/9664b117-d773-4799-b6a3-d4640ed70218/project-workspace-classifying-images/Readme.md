# Excercise files: 

Open the below files to continue with this excercise: 

- [classify_images.py](../data/classify_images.py)

